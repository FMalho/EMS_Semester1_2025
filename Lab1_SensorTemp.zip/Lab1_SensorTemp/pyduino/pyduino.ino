// Pico 2 W (RP2350) — USB Stack: Pico SDK → usa Serial
// Sensores: NTC (GP26/ADC0 via buffer), TMP36 (GP27/ADC1), DS18B20 (GP28 + pull-up 4k7)
// Relé: ON/OFF por comandos seriais (ativo em LOW)

#include <OneWire.h>
#include <DallasTemperature.h>
#include <math.h>

// ---------- Pinos (Pico 2 W) ----------
const int RELAY_PIN   = 2;     // GP2 ligar ao Relay
const int NTC_PIN     = 26;    // GP26 / A0  (lê Vout do op-amp seguidor do nó do divisor)
const int TMP36_PIN   = 27;    // GP27 / A1
const int ONEWIRE_PIN = 28;    // GP28 (DATA do DS18B20) + resistor 4k7 

// ---------- ADC / referência ----------
const float VREF   = 3.3f;
const int   ADCRES = 12;
const int   NSAMP  = 16;

// ---------- NTC NCP15XH103 ----------
const float R0   = 10000.0f;   // 10k @25°C
const float BETA = 3434.0f;    // beta
const float T0_K = 298.15f;    // 25°C em Kelvin


const float RFIXO_BOTTOM = 15000.0f + 10000.0f;  // 25.000 ohm

// ---------- 1-Wire / DS18B20 ----------
OneWire oneWire(ONEWIRE_PIN);
DallasTemperature ds18b20(&oneWire);

// ---------- Utilidades ----------
float readVolts(uint8_t pin) {
  analogReadResolution(ADCRES);
  uint32_t acc = 0;
  for (int i = 0; i < NSAMP; ++i) { acc += analogRead(pin); delayMicroseconds(200); }
  float raw = acc / float(NSAMP);
  return raw * VREF / float((1 << ADCRES) - 1);
}

// Caso B (NTC em cima): 3V3 — NTC — ● — RFIXO — GND
// Rntc = RFIXO * (VREF - v) / v  → depois Beta
float ntcC_fromV_divisorB(float v) {
  if (v <= 0.0f || v >= VREF) return NAN;
  float rntc = RFIXO_BOTTOM * (VREF - v) / v;
  float invT = (1.0f / T0_K) + (1.0f / BETA) * logf(rntc / R0);
  return (1.0f / invT) - 273.15f;
}

void setup() {
  Serial.begin(115200);
  delay(1500);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH); // relé desligado (ativo em LOW)

  pinMode(ONEWIRE_PIN, INPUT_PULLUP); 
  ds18b20.begin();

  Serial.println("READY");
}

void loop() {
  // ---- comandos seriais: ON/OFF ----
  if (Serial.available() > 0) {
    String msg = Serial.readStringUntil('\n');
    msg.trim(); msg.toUpperCase();
    if (msg == "ON")  { digitalWrite(RELAY_PIN, LOW);  Serial.println("Relay: ON"); }
    else if (msg == "OFF") { digitalWrite(RELAY_PIN, HIGH); Serial.println("Relay: OFF"); }
  }

  // ---- NTC (A0/GP26) via buffer do nó do divisor ----
  float v_ntc = readVolts(NTC_PIN);           // tensão no nó (Vout do op-amp)
  float Tntc  = ntcC_fromV_divisorB(v_ntc);   // °C (Beta 3434)

  // ---- TMP36 (A1/GP27) ----
  float v_tmp  = readVolts(TMP36_PIN);
  float Ttmp36 = (v_tmp - 0.500f) / 0.010f;   // TMP36: 10 mV/°C, offset 0.5 V

  // ---- DS18B20 (GP28) ----
  ds18b20.requestTemperatures();
  float Tds = ds18b20.getTempCByIndex(0);

  // ---- saída CSV: Tntc,Vntc,Ttmp,Vtmp,Tds ----
  Serial.print(Tntc, 2);    Serial.print(",");
  Serial.print(v_ntc, 3);   Serial.print(",");
  Serial.print(Ttmp36, 2);  Serial.print(",");
  Serial.print(v_tmp, 3);   Serial.print(",");
  Serial.println(Tds, 2);

  delay(1000);
}
