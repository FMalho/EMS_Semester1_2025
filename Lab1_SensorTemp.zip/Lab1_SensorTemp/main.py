# gui_sensors.py  —  Pico/Arduino serial GUI 
# Mostra NTC, TMP36/LM35, DS18B20. Botão de Relé colorido (ON=verde, OFF=vermelho).
# Lógica: se Relay ON e temperatura >= threshold -> desliga Relay automaticamente.

import tkinter as tk
from tkinter import ttk, messagebox
import threading, queue, time, sys
import serial
import serial.tools.list_ports as lp

# =================== CONFIG ===================
BAUD = 115200       
READ_EVERY = 0.05   
CMD_EOL = "\n"
# ==============================================

# ---------- Serial Worker Thread ----------
class SerialWorker(threading.Thread):
    def __init__(self, port, baud, out_q, on_disconnect):
        super().__init__(daemon=True)
        self.port = port
        self.baud = baud
        self.out_q = out_q
        self.on_disconnect = on_disconnect
        self._stop = threading.Event()
        self.ser = None

    def run(self):
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.2)
            time.sleep(2)  # Pico re-enumera
            # drena banners iniciais 
            t0 = time.time()
            while time.time() - t0 < 2.0:
                line = self.ser.readline().decode(errors="ignore").strip()
                if not line: break
                self.out_q.put(("banner", line))
            # loop principal
            while not self._stop.is_set():
                line = self.ser.readline().decode(errors="ignore").strip()
                if line:
                    self.out_q.put(("line", line))
                else:
                    time.sleep(READ_EVERY)
        except Exception as e:
            self.out_q.put(("error", str(e)))
            self.on_disconnect()
        finally:
            try:
                if self.ser: self.ser.close()
            except: pass

    def write(self, text):
        try:
            if self.ser:
                self.ser.write((text + CMD_EOL).encode())
        except Exception as e:
            self.out_q.put(("error", f"write failed: {e}"))
            self.on_disconnect()

    def stop(self):
        self._stop.set()

# --------------- App (Tkinter) ---------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Temperature Sensors")
        self.resizable(False, False)
        self.ser_thread = None
        self.msg_q = queue.Queue()
        self.relay_on = False        
        self._last_temp_for_control = None

        self._build_ui()
        self._populate_ports()
        self._paint_relay_button()

        self.after(int(READ_EVERY*1000), self._poll_queue)

    # ---------- UI ----------
    def _build_ui(self):
        pad = {'padx': 12, 'pady': 6}
        top = ttk.Frame(self)
        top.grid(row=0, column=0, sticky="ew", **pad)

        ttk.Label(top, text="Port:").grid(row=0, column=0, sticky="w")
        self.port_cmb = ttk.Combobox(top, width=24, state="readonly")
        self.port_cmb.grid(row=0, column=1, sticky="w", padx=(4,8))
        ttk.Button(top, text="↻", width=3, command=self._populate_ports).grid(row=0, column=2, padx=(0,8))
        self.connect_btn = ttk.Button(top, text="Connect", command=self._toggle_connect)
        self.connect_btn.grid(row=0, column=3)

        # botão do relé 
        self.relay_btn = tk.Button(top, text="Relay OFF", width=10,
                                   command=self._toggle_relay, state="disabled",
                                   bg="#d93025", activebackground="#d93025", fg="white")
        self.relay_btn.grid(row=0, column=4, padx=(8,0))

        # Painel de valores
        f = ttk.Frame(self, padding=10)
        f.grid(row=1, column=0, sticky="nsew")

        # NTC
        ttk.Label(f, text="NTC Temperature:", font=("Segoe UI", 16)).grid(row=0, column=0, sticky="w", pady=2)
        self.ntc_temp = ttk.Label(f, text="--.- °C", font=("Segoe UI", 20), foreground="#1a73e8")
        self.ntc_temp.grid(row=0, column=1, sticky="e")
        ttk.Label(f, text="NTC Voltage:", font=("Segoe UI", 12)).grid(row=0, column=2, padx=(20,4))
        self.ntc_volt = ttk.Label(f, text="--.-- V", font=("Segoe UI", 14), foreground="#1a73e8")
        self.ntc_volt.grid(row=0, column=3, sticky="e")

        # TMP36/LM35
        ttk.Label(f, text="LM35/TMP36 Temperature:", font=("Segoe UI", 16)).grid(row=1, column=0, sticky="w", pady=2)
        self.lm_temp = ttk.Label(f, text="--.- °C", font=("Segoe UI", 20), foreground="#0b8043")
        self.lm_temp.grid(row=1, column=1, sticky="e")
        ttk.Label(f, text="LM35 Voltage:", font=("Segoe UI", 12)).grid(row=1, column=2, padx=(20,4))
        self.lm_volt = ttk.Label(f, text="--.-- V", font=("Segoe UI", 14), foreground="#0b8043")
        self.lm_volt.grid(row=1, column=3, sticky="e")

        # DS18B20
        ttk.Label(f, text="DS18B20 Temperature:", font=("Segoe UI", 16)).grid(row=2, column=0, sticky="w", pady=2)
        self.ds_temp = ttk.Label(f, text="--.- °C", font=("Segoe UI", 20), foreground="#a142f4")
        self.ds_temp.grid(row=2, column=1, sticky="e")

        # Threshold (sem checkbox)
        g = ttk.Frame(self, padding=(10,0,10,10))
        g.grid(row=2, column=0, sticky="ew")
        ttk.Label(g, text="Temperature Threshold:", font=("Segoe UI", 14)).grid(row=0, column=0, sticky="w")
        self.threshold = tk.DoubleVar(value=30.0)
        ttk.Spinbox(g, from_=-40, to=125, increment=0.5, width=8,
                    textvariable=self.threshold).grid(row=0, column=1, padx=(6,12))
        ttk.Label(g, text="(Relay ON → corta acima do threshold)").grid(row=0, column=2, padx=(10,0))

        # status
        self.status = ttk.Label(self, text="Disconnected", anchor="w")
        self.status.grid(row=3, column=0, sticky="ew", padx=10, pady=(0,8))

    def _paint_relay_button(self):
        if self.relay_on:
            self.relay_btn.config(text="Relay ON", bg="#188038", activebackground="#188038")
        else:
            self.relay_btn.config(text="Relay OFF", bg="#d93025", activebackground="#d93025")

    def _populate_ports(self):
        ports = [p.device for p in lp.comports()]
        self.port_cmb['values'] = ports
        if ports:
            self.port_cmb.current(0)

    # ---------- Serial ----------
    def _toggle_connect(self):
        if self.ser_thread:
            self._disconnect()
        else:
            port = self.port_cmb.get().strip()
            if not port:
                messagebox.showwarning("Port", "Choose a serial port.")
                return
            self._connect(port)

    def _connect(self, port):
        def on_disc():
            self.after(0, self._disconnect)
        self.ser_thread = SerialWorker(port, BAUD, self.msg_q, on_disc)
        self.ser_thread.start()
        self.connect_btn.config(text="Disconnect")
        self.relay_btn.config(state="normal")
        self.relay_on = False
        self._paint_relay_button()
        self.status.config(text=f"Connected to {port}")

    def _disconnect(self):
        if self.ser_thread:
            try: self.ser_thread.stop()
            except: pass
        self.ser_thread = None
        self.connect_btn.config(text="Connect")
        self.relay_btn.config(state="disabled")
        self.relay_on = False
        self._paint_relay_button()
        self.status.config(text="Disconnected")

    # ---------- Relay ----------
    def _set_relay(self, on: bool):
        if not self.ser_thread: return
        self.relay_on = on
        self._paint_relay_button()
        self.ser_thread.write("ON" if on else "OFF")

    def _toggle_relay(self):
        if not self.ser_thread: return
        self._set_relay(not self.relay_on)

    # ---------- Main loop ----------
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_q.get_nowait()
                if kind == "line":
                    self._handle_line(payload)
                elif kind == "banner":
                    pass
                elif kind == "error":
                    self.status.config(text=f"Serial error: {payload}")
        except queue.Empty:
            pass

        # Lógica de proteção :
        # Se o relé estiver ON e a temperatura >= threshold -> desliga
        if self.relay_on and self._last_temp_for_control is not None:
            if self._last_temp_for_control >= self.threshold.get():
                self._set_relay(False)

        self.after(int(READ_EVERY*1000), self._poll_queue)

    # Aceita 5 colunas (Tntc,Vntc,Ttmp,Vtmp,Tds) ou 6 colunas (time,Tds,Ttmp,Tntc,Vtmp,Vntc)
    def _handle_line(self, line):
        parts = [p.strip() for p in line.split(",")]
        try:
            if len(parts) == 5:
                # Tntc, Vntc, Ttmp, Vtmp, Tds
                tntc = float(parts[0])
                vntc = float(parts[1])
                ttmp = float(parts[2])
                vtmp = float(parts[3])
                tds  = float(parts[4])
            elif len(parts) >= 6:
                # time, Tds, Ttmp, Tntc, Vtmp, Vntc
                tds  = float(parts[1])
                ttmp = float(parts[2])
                tntc = float(parts[3])
                vtmp = float(parts[4])
                vntc = float(parts[5])
            else:
                return
        except Exception:
            return

        # Atualiza rótulos
        self.ntc_temp.config(text=f"{tntc:.2f} °C")
        self.ntc_volt.config(text=f"{vntc:.2f} V")
        self.lm_temp.config(text=f"{ttmp:.2f} °C")
        self.lm_volt.config(text=f"{vtmp:.2f} V")
        self.ds_temp.config(text=f"{tds:.2f} °C")

        # Usa DS18B20 para a proteção 
        self._last_temp_for_control = tds

if __name__ == "__main__":
    App().mainloop()

