#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ADC_PIN A1
#define pi 3.1416

/*
  Simple floating-point FIR filter class for Arduino.
  Originally designed in C++, adapted for Arduino IDE.
*/

template <typename FloatType, int num_coeffs, const FloatType* coeffs>
class FirFilter {
public:
  FirFilter() : current_index_(0) {
    for (int i = 0; i < num_coeffs; ++i)
      history_[i] = 0.0;
  }

  void put(FloatType value) {
    history_[current_index_++] = value;
    if (current_index_ == num_coeffs)
      current_index_ = 0;
  }

  FloatType get() {
    FloatType output = 0.0;
    int index = current_index_;
    for (int i = 0; i < num_coeffs; ++i) {
      if (index != 0) {
        --index;
      } else {
        index = num_coeffs - 1;
      }
      output += history_[index] * coeffs[i];
    }
    return output;
  }

private:
  FloatType history_[num_coeffs];
  int current_index_;
};

#define FILTER1_LENGTH 41  // must match number of coefficients below

const float filter1_coeffs[FILTER1_LENGTH] = {
  -0.0027716425, -0.0023105398, 0.0007821936, 0.0068549314, 0.0122860724,
  0.0119126047, 0.00335683, -0.009358639, -0.0168301749, -0.0107970462,
  0.0078667618, 0.0265385988, 0.0278980038, 0.0036082126, -0.0349341339,
  -0.0585397498, -0.0366348663, 0.0410391357, 0.1524059898, 0.2508659974,
  0.2901031626, 0.2508659974, 0.1524059898, 0.0410391357, -0.0366348663,
  -0.0585397498, -0.0349341339, 0.0036082126, 0.0278980038, 0.0265385988,
  0.0078667618, -0.0107970462, -0.0168301749, -0.009358639, 0.00335683,
  0.0119126047, 0.0122860724, 0.0068549314, 0.0007821936, -0.0023105398,
  -0.0027716425
};  

float x[16] = {0};
float output;
// ------------------------------------------------------------
// Arduino test
// ------------------------------------------------------------

FirFilter<float, FILTER1_LENGTH, filter1_coeffs> filter1;

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  while (!Serial) ; // wait for Serial on boards like Leonardo or Pico

  Serial.println("Starting FIR filter test...");
}

void loop() {
  static unsigned long lastMicros = 0;
  static float t = 0.0;

  // Sample every 500 µs (2 kHz sample rate)
  if (micros() - lastMicros >= 500) {
    lastMicros = micros();
    
    static float t = 0.0;
    float freq = 250.0; // Hz — muda para testar outras frequências;;
    x[0] = 3.3f * sin(2 * PI * freq * t);
    t += 1.0 / 2000.0;
    // Filter the input
    for (int i = 15; i > 0; i--) {
      filter1.put(x[i]);
      output = filter1.get();
    }
    

    Serial.print(x[0]);
    Serial.print(",");
    Serial.println(output);
  }
}
