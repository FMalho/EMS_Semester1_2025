#define ADC_PIN A1   // ADC analog input

float b[] = { 0.00000004, 0.00000056, 0.00000389, 0.00001686, 0.00005057, 0.00011125, 0.00018542, 0.00023839, 0.00023839, 0.00018542, 0.00011125, 0.00005057, 0.00001686, 0.00000389, 0.00000056, 0.00000004 };
float a[] = { 1.00000000, -7.49129567, 27.31208094, -63.79255085, 106.21236063, -133.03378907, 129.12640464, -98.67640938, 59.74534947, -28.61588328, 10.73949421, -3.09788443, 0.66418824, -0.09983343, 0.00939948, -0.00041759 };


// Buffers for input (x) and output (y)
float x[16] = {0};
float y[16] = {0};

const unsigned long sampleInterval = 125; // 125 µs = 2000 Hz sampling
unsigned long previousTimer = 0;

void setup() {
  Serial.begin(115200);        // Fast enough for Serial Plotter
  analogReadResolution(12);    // 12-bit ADC 
  pinMode(ADC_PIN, INPUT);
}

void loop() {
  unsigned long timer = micros();

  // Run at 2 kHz
  if ((timer - previousTimer) >= sampleInterval) {

    // === Read ADC and convert to volts ===
    //x[0] = (float)analogRead(ADC_PIN) * (3.3f / 4095.0f);
    
    //Input Sine Wave to test
    static float t = 0.0;
    float freq = 250.0; // Hz — muda para testar outras frequências;;
    x[0] = 3.3f * sin(2 * PI * freq * t);
    t += 1.0 / 2000.0;
    
    // === 3rd-order IIR filter ===
   y[0] = b[0]*x[0] + b[1]*x[1] + b[2]*x[2] + b[3]*x[3] + b[4]*x[4] + b[5]*x[5] + b[6]*x[6] + b[7]*x[7] + b[8]*x[8] + b[9]*x[9] + b[10]*x[10] + b[11]*x[11] + b[12]*x[12] + b[13]*x[13] + b[14]*x[14] + b[15]*x[15] - a[1]*y[1] - a[2]*y[2] - a[3]*y[3] - a[4]*y[4] - a[5]*y[5] - a[6]*y[6] - a[7]*y[7] - a[8]*y[8] - a[9]*y[9] - a[10]*y[10] - a[11]*y[11] - a[12]*y[12] - a[13]*y[13] - a[14]*y[14] - a[15]*y[15];
    // === Send to Serial Plotter ===
    //Serial.println(y[0]);  // plot filtered signal
    // Input vs Output signals
    Serial.print(x[0]); Serial.print("\t"); Serial.println(y[0]);

    // === Shift samples ===
    for (int i = 15; i > 0; i--) {
      x[i] = x[i - 1];
      y[i] = y[i - 1];
    }

    previousTimer = timer;
  }
}