import numpy as np
import scipy.signal as signal
import matplotlib.pyplot as plt

def design_and_analyze_iir_filter():

    # --- 1. Define the Filter Specifications ---
    filter_order = 15
    cutoff_frequency = 250  # Desired cutoff frequency (Hz)
    sampling_frequency = 2000.0 # Sampling frequency (Hz)

    print(f"--- Designing a {filter_order}-order Bessel Low-Pass IIR Filter ---")
    print(f"Cutoff Frequency: {cutoff_frequency} Hz")
    print(f"Sampling Frequency: {sampling_frequency} Hz\n")

    b, a = signal.butter(
        N=filter_order,
        Wn=cutoff_frequency,
        btype='low',
        analog=False,
        fs=sampling_frequency
    )

    # --- 3. Print the Calculated Coefficients ---
    print("--- Calculated Filter Coefficients ---")
    b_str = ", ".join([f"{x:.8f}" for x in b])
    print(f"float b[] = {{ {b_str} }};")
    a_str = ", ".join([f"{x:.8f}" for x in a])
    print(f"float a[] = {{ {a_str} }};")

    # --- 4. Plot the Filter's Frequency Response ---
    w, h = signal.freqz(b, a, worN=8000, fs=sampling_frequency)
    magnitude_db = 20 * np.log10(np.abs(h))
    phase_degrees = np.unwrap(np.angle(h)) * 180 / np.pi
    
    # Create the plots
    fig, axs = plt.subplots(2, 1, figsize=(12, 9))
    fig.suptitle('Frequency Response of the Designed Bessel Filter', fontsize=16)

    # Magnitude Plot
    axs[0].plot(w, magnitude_db, label='Filter Response')
    axs[0].axvline(cutoff_frequency, color='r', linestyle='--', label=f'Cutoff Freq. ({cutoff_frequency} Hz)')
    axs[0].set_title('Magnitude Response')
    axs[0].set_xlabel('Frequency (Hz)')
    axs[0].set_ylabel('Magnitude (dB)')
    axs[0].grid(True)
    axs[0].legend()
    axs[0].set_ylim(-100, 5)

    # Phase Plot
    axs[1].plot(w, phase_degrees)
    axs[1].set_title('Phase Response')
    axs[1].set_xlabel('Frequency (Hz)')
    axs[1].set_ylabel('Phase (degrees)')
    axs[1].grid(True)

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

# --- Run the main function ---
if __name__ == "__main__":
    design_and_analyze_iir_filter()