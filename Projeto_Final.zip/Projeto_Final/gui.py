import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import serial
import threading
import csv
from datetime import datetime

class EMS_Advanced_GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("EMS Smart Fusion System - Console de Controlo")
        self.root.geometry("600x500")
        
        # Variáveis de Dados
        self.data_log = []
        self.is_connected = False
        self.is_logging = False

        # Configuração da Interface
        self.setup_ui()

    def setup_ui(self):
        # Frame de Conectividade
        conn_frame = ttk.LabelFrame(self.root, text=" Configuração Serial ")
        conn_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(conn_frame, text="Porta:").pack(side="left", padx=5)
        self.port_entry = ttk.Entry(conn_frame, width=10)
        # ALTERAÇÃO 1: Mudei para COM7 como pediu
        self.port_entry.insert(0, "COM7") 
        self.port_entry.pack(side="left", padx=5)
        
        self.btn_connect = ttk.Button(conn_frame, text="Conectar", command=self.toggle_connection)
        self.btn_connect.pack(side="left", padx=10, pady=5)

        # Painel de Visualização
        display_frame = ttk.LabelFrame(self.root, text=" Monitorização em Tempo Real ")
        display_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.lbl_dist = ttk.Label(display_frame, text="Distância: -- cm", font=("Helvetica", 18, "bold"))
        self.lbl_dist.pack(pady=15)
        
        self.lbl_vel = ttk.Label(display_frame, text="Velocidade: -- km/h", font=("Helvetica", 18, "bold"))
        self.lbl_vel.pack(pady=15)

        # Painel de Configuração
        config_frame = ttk.LabelFrame(self.root, text=" Painel de Configuração ")
        config_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(config_frame, text="Freq. Ultrassom (ms):").grid(row=0, column=0, padx=5, pady=5)
        self.spin_freq = ttk.Spinbox(config_frame, from_=100, to=2000, increment=100, width=10)
        self.spin_freq.set(500)
        self.spin_freq.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Button(config_frame, text="Atualizar Parâmetros", command=self.send_config).grid(row=0, column=2, padx=10)

        # Data Logging
        log_frame = ttk.Frame(self.root)
        log_frame.pack(fill="x", padx=10, pady=10)
        
        self.btn_log = ttk.Button(log_frame, text="Iniciar Log", command=self.toggle_logging)
        self.btn_log.pack(side="left", padx=5)
        
        ttk.Button(log_frame, text="Exportar para CSV", command=self.export_csv).pack(side="left", padx=5)

    def toggle_connection(self):
        if not self.is_connected:
            try:
                # Timeout reduzido para não travar a interface
                self.ser = serial.Serial(self.port_entry.get(), 115200, timeout=0.1) 
                self.is_connected = True
                self.btn_connect.config(text="Desconectar")
                self.listen_thread = threading.Thread(target=self.serial_listener, daemon=True)
                self.listen_thread.start()
            except Exception as e:
                messagebox.showerror("Erro de Conexão", f"Não foi possível abrir a porta: {e}")
        else:
            self.is_connected = False
            # Pequena pausa para a thread fechar antes de fechar a porta
            self.root.after(100, self.close_serial)

    def close_serial(self):
        try:
            self.ser.close()
        except:
            pass
        self.btn_connect.config(text="Conectar")

    def serial_listener(self):
        while self.is_connected:
            try:
                if self.ser.in_waiting > 0:
                    # Lê a linha
                    line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                    
                    if line:
                        print(f"Recebido: {line}") 
                        
                        
                        # Verificamos se a linha tem os separadores que esperamos
                        if "Dist:" in line and "|" in line:
                            try:
                                # 1. Divide a linha no símbolo "|"
                                parts = line.split('|') 

                                # 2. Limpa o lixo da primeira parte para sobrar só o numero
                                dist = parts[0].replace("Dist:", "").replace("cm", "").strip()
                                
                                # 3. Limpa o lixo da segunda parte
                                vel = parts[1].replace("Vel:", "").strip()

                                # 4. Atualiza a GUI
                                self.root.after(0, lambda: self.update_display(dist, vel))
                                
                                if self.is_logging:
                                    self.data_log.append([datetime.now().strftime("%H:%M:%S"), dist, vel])
                            except ValueError:
                                pass # Ignora linhas mal formatadas
                                
            except Exception as e:
                print(f"Erro na leitura: {e}")
                continue

    def update_display(self, dist, vel):
        self.lbl_dist.config(text=f"Distância: {dist} cm")
        self.lbl_vel.config(text=f"Velocidade: {vel} km/h")

    def send_config(self):
        if self.is_connected:
            try:
                cmd = f"FREQ:{self.spin_freq.get()}\n"
                self.ser.write(cmd.encode())
                print(f"Comando enviado: {cmd}")
            except Exception as e:
                messagebox.showerror("Erro", f"Falha ao enviar: {e}")
        else:
            messagebox.showwarning("Aviso", "Conecte o dispositivo primeiro!")

    def toggle_logging(self):
        self.is_logging = not self.is_logging
        self.btn_log.config(text="Parar Log" if self.is_logging else "Iniciar Log")

    def export_csv(self):
        if not self.data_log:
            messagebox.showwarning("Aviso", "Não há dados para exportar.")
            return
        
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if path:
            try:
                with open(path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(["Timestamp", "Distancia(cm)", "Velocidade(km/h)"])
                    writer.writerows(self.data_log)
                messagebox.showinfo("Sucesso", "Dados exportados com sucesso!")
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao gravar ficheiro: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = EMS_Advanced_GUI(root)
    root.mainloop()