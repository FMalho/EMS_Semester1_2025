#include <WiFi.h>
#include <PubSubClient.h>

// --- Configurações de Rede ---
const char* ssid = "iuri";
const char* password = "12345678";
const char* mqtt_server = "172.29.62.66"; 

// --- Configurações do Projeto ---
const char* topic = "ems/t1/g4"; 
const char* client_id = "Pico2W_Sensor_Node"; 

// --- Pinos ---
const int trigPin = 3;      // GP3 (HC-SR04 Trigger)
const int echoPin = 2;      // GP2 (HC-SR04 Echo)
const int radarPin = 28;    // GP28 (Saída Analógica do Radar U4)

// --- Constantes Radar ---
const float radarConst = 19.49; // Constante HB100
const int centroRef = 2048;     // 1.65V (Meio do ADC 12-bit)
const int histerese = 300;      // Margem para ignorar ruído

WiFiClient picoClient;
PubSubClient client(picoClient);

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("A ligar a rede: ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN)); 
  }

  digitalWrite(LED_BUILTIN, HIGH); 
  Serial.println("");
  Serial.println("WiFi ligado!");
  Serial.print("Endereco IP do Pico: ");
  Serial.println(WiFi.localIP());
  Serial.print("A tentar ligar ao Servidor MQTT: ");
  Serial.println(mqtt_server);
}

void reconnect() {
  if (!client.connected()) {
    Serial.print("A tentar ligacao MQTT... ");
    if (client.connect(client_id)) {
      Serial.println("ligado ao broker!");
      client.subscribe(topic);
    } else {
      Serial.print("falhou, rc=");
      Serial.print(client.state());
      Serial.println(" (tento novamente no proximo ciclo)");
    }
  }
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  
  // Configuração HC-SR04
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  
  // Configuração Radar
  pinMode(radarPin, INPUT);
  analogReadResolution(12); 
  
  Serial.begin(115200);
  delay(3000); 

  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // --- 1. LEITURA DE DISTÂNCIA (HC-SR04) ---
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  unsigned long duration = pulseIn(echoPin, HIGH, 30000UL); 
  float distance = (duration > 0) ? (duration * 0.0343) / 2.0 : 0;

  // --- 2. LEITURA DE VELOCIDADE (Radar U4) ---
  long ondasContadas = 0;
  unsigned long janelaTempo = 100; // Tempo de amostragem (ms)
  unsigned long inicioRadar = millis();
  bool estavaEmCima = false;

  while (millis() - inicioRadar < janelaTempo) {
    int valor = analogRead(radarPin);

    // Algoritmo de deteção de onda (Zero-Crossing com histerese)
    if (!estavaEmCima && valor > (centroRef + histerese)) {
      estavaEmCima = true;
      ondasContadas++; 
    }
    else if (estavaEmCima && valor < (centroRef - histerese)) {
      estavaEmCima = false;
    }
  }

  // Cálculo da Velocidade: Freq = Pulsos / 0.1s
  float frequencia = (float)ondasContadas / (janelaTempo / 1000.0);
  float velocity = frequencia / radarConst;

  // Filtro: Se for muito lento (< 1 km/h), assumimos 0 para não enviar lixo
  if (velocity < 1.0) { velocity = 0.0; }


  // --- 3. PRINT E PUBLICAÇÃO ---
  // Verifica se a leitura do HC-SR04 foi válida antes de enviar
  if (distance > 0 && distance < 400) {
    
    Serial.print("Dist: ");
    Serial.print(distance);
    Serial.print(" cm | Vel: ");
    Serial.print(velocity);
    Serial.println(" km/h");

    if (client.connected()) {
      // Formata a mensagem com os dois valores reais
      String payload = "sensores,origem=pico2w distancia=" + String(distance) + ",velocidade=" + String(velocity);
      client.publish(topic, payload.c_str());
    }
  } else {
    Serial.println("Erro de leitura no HC-SR04");
  }

  // Pequeno delay antes da próxima medição
  delay(200); 
}